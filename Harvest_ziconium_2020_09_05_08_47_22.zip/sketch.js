var bananaImage
var obstacleImage
var obstaclegroup
 var background
 var score
function preload(){
backImage=loadImage("jungle.jpg");
  bananaImage=loadImage("banana.png");
obstacleImage=loadImage("obstacle.png");
  player_running=
   loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png") 
 }




function setup() {
  createCanvas(400, 400);
background.addImage("backImage",background);
  background.velocityX=-3;
}

function draw() {
  background(220);
  var ground=createSprite(200,350,400,20);
}